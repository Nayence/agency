import React from "react";

const QNS = () => (
  <div class="content is-normal">
    <h1 class="has-text-centered is-size-3">Une Prestation de qualité</h1>
    <p class="has-text-centered is-size-5">Nayence agency propose une prestation personnalisé et de qualité, toujours à l'écoute de ses clients, notre agence propose un support adapté à vos enjeux, un support à tous les utilisateurs, un support adapté à votre secteur, un support innovant, et tout ça depuis 2015 !</p>
  </div>
);

export default QNS;