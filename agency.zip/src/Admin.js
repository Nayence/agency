import React from "react";

const Admin = () => (
    <div class="container">
        <div class="columns is-gapless">
            <div class="column">
                ID Client
            </div>
            <div class="column">
                Projets
            </div>
            <div class="column">
                Support
            </div>
            <div class="column">
                Secteur
            </div>
        </div>
    </div>
  );

export default Admin;